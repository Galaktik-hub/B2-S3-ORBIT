<?php

/**
 * Test fixture.
 *
 * Used in the `PHPMailer\LocalizationTest` to test the fall-back logic.
 */

$PHPMAILER_LANG['empty_message'] = 'XD Lang-script file found';
